<!DOCTYPE HTML>
<html lang="en_US">
<head>
	<meta charset="UTF-8">
	<title>Happy Diwali</title>
</head>
<body background="images/back.jpg" style="background-size:1366px 680px;">

	<form action="diwali.php" method="get">
    	<label for="name">Enter Text</label>
        <input type="text" name="name" id="name">
        
        <input type="submit" name="submit" value="Let's Go">
    </form>
	
</body>
</html>